const express = require("express");
const jwt = require("jsonwebtoken");

const app = express();

const PORT = 3000;
const JWT_SECRET = "my_secret_key";

// Middleware
app.use(express.json());

// Users array
const users = [];

// Students array
const students = [
    {
        id: 1,
        name: "Rahul",
        age: 20,
        course: "CSE"
    },
    {
        id: 2,
        name: "Priya",
        age: 21,
        course: "ECE"
    }
];

// Home API
app.get("/", (req, res) => {
    res.json({
        message: "Welcome to Secure Student API"
    });
});

// Register API
app.post("/register", (req, res) => {
    const { username, password, role } = req.body;

    if (!username || !password) {
        return res.status(400).json({
            message: "Username and password are required"
        });
    }

    const existingUser = users.find(
        user => user.username === username
    );

    if (existingUser) {
        return res.status(400).json({
            message: "User already exists"
        });
    }

    const newUser = {
        id: users.length + 1,
        username: username,
        password: password,
        role: role || "student"
    };

    users.push(newUser);

    res.status(201).json({
        message: "User registered successfully"
    });
});

// Login API
app.post("/login", (req, res) => {
    const { username, password } = req.body;

    const user = users.find(
        user =>
            user.username === username &&
            user.password === password
    );

    if (!user) {
        return res.status(401).json({
            message: "Invalid username or password"
        });
    }

    const token = jwt.sign(
        {
            userId: user.id,
            username: user.username,
            role: user.role
        },
        JWT_SECRET,
        {
            expiresIn: "10s"
        }
    );

    res.json({
        message: "Login successful",
        token: token
    });
});

// JWT Authentication Middleware
function authenticateToken(req, res, next) {

    const authHeader = req.headers.authorization;

    if (!authHeader) {
        return res.status(401).json({
            message: "Access denied. Token is missing."
        });
    }

    const token = authHeader.split(" ")[1];

    if (!token) {
        return res.status(401).json({
            message: "Access denied. Token is missing."
        });
    }

    try {
        const decoded = jwt.verify(token, JWT_SECRET);

        req.user = decoded;

        next();

    } catch (error) {
        return res.status(401).json({
            message: "Invalid or expired token"
        });
    }
}

// Get all students
app.get("/students", authenticateToken, (req, res) => {
    res.json({
        message: "Students retrieved successfully",
        students: students
    });
});

// Add student
app.post("/students", authenticateToken, (req, res) => {

    const { name, age, course } = req.body;

    if (!name || !age || !course) {
        return res.status(400).json({
            message: "Name, age and course are required"
        });
    }

    const newStudent = {
        id: students.length + 1,
        name: name,
        age: age,
        course: course
    };

    students.push(newStudent);

    res.status(201).json({
        message: "Student added successfully",
        student: newStudent
    });
});

// Get student by ID
app.get("/students/:id", authenticateToken, (req, res) => {

    const id = parseInt(req.params.id);

    const student = students.find(
        student => student.id === id
    );

    if (!student) {
        return res.status(404).json({
            message: "Student not found"
        });
    }

    res.json(student);
});

// 404 middleware
app.use((req, res) => {
    res.status(404).json({
        message: "Route not found"
    });
});

// Start server
app.listen(PORT, () => {
    console.log("=================================");
    console.log("Secure Student API Server");
    console.log(`Server running on port ${PORT}`);
    console.log("=================================");
});