const express = require("express");
const { foods, orders } = require("../data");

const router = express.Router();

// GET /api/orders
router.get("/", (req, res) => {
  res.json(orders);
});

// POST /api/orders
// Body: { "customerName": "Nithish", "items": [ { "foodId": 101, "quantity": 2 } ] }
router.post("/", (req, res) => {
  const { customerName, items } = req.body || {};

  if (!customerName || !Array.isArray(items) || items.length === 0) {
    return res
      .status(400)
      .json({ error: "customerName and a non-empty items array are required" });
  }

  const lineItems = [];
  let total = 0;

  for (const item of items) {
    const food = foods.find((f) => f.id === Number(item.foodId));
    const quantity = Number(item.quantity) || 1;

    if (!food) {
      return res.status(400).json({ error: `Invalid foodId: ${item.foodId}` });
    }
    if (!Number.isInteger(quantity) || quantity < 1) {
      return res.status(400).json({ error: "quantity must be a positive integer" });
    }

    lineItems.push({ foodId: food.id, name: food.name, quantity, price: food.price });
    total += food.price * quantity;
  }

  const order = {
    id: orders.length + 1,
    customerName,
    items: lineItems,
    total,
    status: "PLACED",
    createdAt: new Date().toISOString(),
  };

  orders.push(order);
  res.status(201).json(order);
});

module.exports = router;
