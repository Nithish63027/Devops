const express = require("express");
const { restaurants } = require("../data");

const router = express.Router();

// GET /api/restaurants
router.get("/", (req, res) => {
  res.json(restaurants);
});

// GET /api/restaurants/:id
router.get("/:id", (req, res) => {
  const restaurant = restaurants.find((r) => r.id === Number(req.params.id));
  if (!restaurant) {
    return res.status(404).json({ error: "Restaurant not found" });
  }
  res.json(restaurant);
});

module.exports = router;
