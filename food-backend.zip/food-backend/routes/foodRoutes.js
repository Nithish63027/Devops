const express = require("express");
const { foods } = require("../data");

const router = express.Router();

// GET /api/foods  (optional filter: ?restaurantId=1)
router.get("/", (req, res) => {
  const { restaurantId } = req.query;
  if (restaurantId) {
    return res.json(foods.filter((f) => f.restaurantId === Number(restaurantId)));
  }
  res.json(foods);
});

// GET /api/foods/:id
router.get("/:id", (req, res) => {
  const food = foods.find((f) => f.id === Number(req.params.id));
  if (!food) {
    return res.status(404).json({ error: "Food item not found" });
  }
  res.json(food);
});

module.exports = router;
