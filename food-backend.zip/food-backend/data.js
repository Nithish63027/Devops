// In-memory sample data (swap for a database later, see docker-compose.yml)
const restaurants = [
  { id: 1, name: "Spice Kitchen", cuisine: "Indian" },
  { id: 2, name: "Pizza Palace", cuisine: "Italian" },
];

const foods = [
  { id: 101, name: "Chicken Biryani", restaurantId: 1, price: 220 },
  { id: 102, name: "Veg Biryani", restaurantId: 1, price: 180 },
  { id: 201, name: "Margherita Pizza", restaurantId: 2, price: 250 },
  { id: 202, name: "Pepperoni Pizza", restaurantId: 2, price: 320 },
];

const orders = [];

module.exports = { restaurants, foods, orders };
