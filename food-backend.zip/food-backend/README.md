# Food Delivery Backend (Dockerized)

Node.js + Express REST API for restaurants, foods and orders, packaged as a Docker image.

## APIs

| Method | Endpoint | Description |
|---|---|---|
| GET | /health | Health check |
| GET | /api/restaurants | List restaurants |
| GET | /api/restaurants/:id | One restaurant |
| GET | /api/foods | List foods (`?restaurantId=1` to filter) |
| GET | /api/foods/:id | One food item |
| POST | /api/orders | Place an order |
| GET | /api/orders | List orders |

POST /api/orders body:

```json
{ "customerName": "Nithish", "items": [ { "foodId": 101, "quantity": 2 } ] }
```

## Run locally (no Docker)

```bash
npm install
npm start
```

## Build and run with Docker

```bash
docker build -t food-backend:v1 .
docker images

docker run -d --restart unless-stopped -p 5000:5000 --name food-api food-backend:v1
```

Test in Postman: http://localhost:5000/api/restaurants, /api/foods, /api/orders, /health

## Container management

```bash
docker ps                  # STATUS shows (healthy) after the first health check
docker logs food-api
docker inspect food-api
docker inspect --format='{{json .State.Health}}' food-api
docker stop food-api
docker start food-api
docker exec food-api whoami   # prints "node" (non-root)
```

## Environment variables

```bash
docker run -d -p 8080:8080 -e PORT=8080 --name food-api food-backend:v1
```

Note: the Dockerfile health check targets port 5000. If you change PORT, update the HEALTHCHECK too.

## Image versioning

```bash
docker build -t food-backend:v2 .
docker tag food-backend:v2 food-backend:latest
```

## Docker network (bonus)

```bash
docker network create food-network
docker run -d --network food-network -p 5000:5000 --name food-api food-backend:v1
docker network inspect food-network
```

With MongoDB (see docker-compose.yml):

```bash
docker compose up -d --build
docker compose ps
docker compose down
```

The compose file starts the API and a MongoDB container on `food-network` and passes `MONGO_URL`. The API currently stores data in memory; wiring it to Mongo (e.g. with mongoose) is the next step.
